import json
from common.methods import set_progress
from servicecatalog.models import ProvisionServerServiceItem
from azure.mgmt.compute.models import VirtualMachineExtension

def run(job, *args, **kwargs):

    
    
    server = kwargs.get('server')
    rh = server.resource_handler.cast()
    client = rh.get_api_wrapper().compute_client
    
    vm_name = server.get_vm_name()
    
    azure_server_info = rh.tech_specific_server_details(server)
    resource_group_name = azure_server_info.resource_group
    
    
    command_id = 'RunPowerShellScript'
    
    script = """{{ ps_script }}"""

    run_command_parameters = {
        'command_id': command_id,
        'script': script.splitlines()
    }
    
    try:
        poller = client.virtual_machines.run_command(
            resource_group_name,
            vm_name,
            run_command_parameters
            )
    
        result = poller.result()
        server.stream_output(True, result.value[0].message)
        if "succeeded" in result.value[0].code:
            return "SUCCESS", f"WinRM installed and available on {vm_name}" , ""
        
    except Exception as e:
        return "FAILURE", e, e
    
    return "FAILURE", "Failed to run PS script", ""